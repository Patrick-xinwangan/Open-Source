// Fibonacci.cpp: 定义控制台应用程序的入口点。
//
//循环队列，注意rear=（rear+1）% k 很关键
#include<stdio.h>
#define kk  4
#define max 200
struct queue
{
    int elem[kk];
    int  rear;
} cq; // rear指向队尾元素
int f[100], n;   //用数组f存放所求序列中的所有元素

void fb(int k)//k表示循环队列里有几个元素
{
    int i, j;
    for (i = 0; i <= k - 2; i++) { f[i] = 0; cq.elem[i] = 0; }        //为前k-1个元素赋初值0，并放入队列cq
    cq.elem[k - 1] = f[k - 1] = 1;    //为第k个元素赋值，并放入队列cq
    cq.rear = k - 1;
    n = k;
    while (cq.elem[cq.rear]<max)//利用循环队列依次求f[n]
    {
        f[n] = 0;
        for (j = 0; j<k; j++)  f[n] = f[n] + cq.elem[j]; //计算结果
        cq.rear = (cq.rear + 1) % k;//Important!!!
        cq.elem[cq.rear] = f[n];  //将结果存入队列中去
        n++;//这里n多加了
    }              //利用循环队列依次求f[n]
    if (cq.elem[cq.rear]>max)  n = n - 2; else n = n - 1;
    //跳出了上面的while，说明队尾比max大或者相等，n在结束多加了一次，至少要减一，若比max大，再要减一次；若相等，好的，不用减
}
int main()
{
    int i;
    fb(kk);   for (i = 0; i <= n; i++)   printf("  %d  ", f[i]);

}
