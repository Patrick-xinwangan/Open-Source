#include<stdio.h>
#include<stdlib.h>
struct clerkMessage {
    char name[50];
    char number[50];
    char factor[50];
};
struct Node
{
    int nums;
    clerkMessage staff;
    Node *next;
};
void creatList(Node *head)// 创建一个n个结点的链表
{
    head->next = NULL;
    head->nums = 0;
    int n;
    printf("输入您需要输入员工个数\n");
    //cout << "输入您要输入员工个数" << endl;
    scanf_s("%d", &n);
    //cin >> n;
    for (int i = n-1; i >=0; i--)
    {
        //Node *node = new Node[1];
        Node *node = (Node*)malloc(sizeof(Node));
        //cout << "请输入姓名，工号，职位（以空格隔开）" << endl;
        printf("请输入姓名，工号，职位（以空格隔开）\n");
        scanf_s("%s%s%s", node->staff.name,50, node->staff.number,50, node->staff.factor,50);
        //cin >> node->staff.name >> node->staff.number >> node->staff.factor;
        node->nums = i + 1;
        node->next = head->next;
        head->next = node;
    }
}
void deleteElem(Node*head, int n)
{
    Node *p = head;
    while(p!=NULL)
    {
        if (p->next->nums == n)
        {
            Node *q = p->next;
            p->next = p->next->next;
            free(q);
            //delete[] q;
            return;
        }
        p = p->next;
    }
}
void addElem(Node* head, int n,Node* newElem)//根据号来加入队列
{
    Node *p = head;
    for (int i = 0; i <= n - 2; i++)
        p = p->next;
    Node *q = p->next;
    p->next = newElem;
    newElem->next = q;
}
int anyVacant(Node*head)
{
    Node* p = head;
    int i = 0;
    while (p!= NULL)
    {
        if (p->nums != i)
            return i;
        p = p->next;
        i++;
    }
    return i;
}
void quitFunction(Node*head,int n)
{
    deleteElem(head, n);
}
void joinFunction(Node*head)
{
    Node *newnode = new Node[1];
    int newNum = anyVacant(head);
    //cout << "输入入职员工的信息:姓名，工号，部门" << endl;
    printf("输入入职员工的信息:姓名，工号，部门\n");
    //cin >> newnode->staff.name >> newnode->staff.number >> newnode->staff.factor;
    scanf_s("%s%s%s", newnode->staff.name,50, newnode->staff.number,50, newnode->staff.factor,50);
    newnode->nums = newNum;
    addElem(head, newNum,newnode);
}
void printMessage(Node*head)
{
    Node *p = head->next;
    while (p != NULL)
    {
        //	cout << "The  " << p->nums << "worker: " << p->staff.name << " " << p->staff.number << " " << p->staff.factor << endl;
        printf("The%dworker:%s %s %s\n", p->nums, p->staff.name, p->staff.number, p->staff.factor);
        p = p->next;
    }
}
void destroyList(Node *head)
{
    Node*p = head;
    while (p != NULL)
    {
        Node*q = p;
        p = p->next;
        free(q);
        //delete[] q;
    }
}
int main()
{
    //Node*head=new Node[1];
    Node*head = (Node*)malloc(sizeof(Node));
    printf("请尽量输入的数字大于3，因为设定的3号员工离职\n");
    creatList(head);
    quitFunction(head, 3);//5号员工离职
    printMessage(head);
    joinFunction(head);
    printMessage(head);
    joinFunction(head);
    printMessage(head);
    destroyList(head);
    system("pause");
    return 0;
}

