#include<stdio.h>
//鞍点问题测试案例 4 4 2 1 3 6 3 4 4 7 7 6 5 8 5 3 2 1
typedef struct SaddlePoint1
{
    int m, n;
    int data;
} SaddlePoint;
SaddlePoint pointArray[1000];
int a[1000][1000];
int row, col;
int findInRow(int row1)//find the minimum element in a certain  row
{
    int minCol = 0;
    for (int i = 0; i <= col - 1; i++)
        if (a[row1][minCol] > a[row1][i])
            minCol = i;
    return a[row1][minCol];//return the element which is the minimum
}
int findInColumn(int col1)//find the maximum element in a certain column
{
    int maxrow = 0;
    for (int i = 0; i <= row - 1; i++)
    {
        if (a[maxrow][col1] < a[i][col1])
            maxrow = i;
    }
    return a[maxrow][col1];
}
int main()
{
    int k = 0;
    scanf("%d%d", &row, &col);//input the numbers of rows and columns
    for (int i = 0; i <= row - 1; i++)
        for (int j = 0; j <= col - 1; j++)
            scanf("%d", a[i] + j);
    for (int i = 0; i <= row - 1; i++)//这里用循环的原因是因为鞍点可能不是一个，一列或一行如果有重复元素，那么不用循环就会出
    {
        int minnum=findInRow(i);
        for (int j = 0; j <= col - 1; j++)
        {
            int maxnum = findInColumn(j);
            if (a[i][j] == minnum && a[i][j] == maxnum)
            {
                pointArray[k].data = minnum;
                pointArray[k].m = i;
                pointArray[k].n = j;
                k++;
            }
        }
    }
    if (k > 0)
    {
        for (int i = 0; i <= k-1; i++)
        {
            printf("The %d saddlepoint's context are as following:\n ",i+1);
            printf("Row:%d Column:%d Data:%d\n", pointArray[i].m, pointArray[i].n, pointArray[i].data);
        }
    }
    else
        printf("No saddlepoint existed\n");
    return 0;
}
