#include<bits/stdc++.h>
using namespace std;
int depth;
int max;
typedef enum{ATOM,LIST}ElemTag;
typedef struct GLNode {
    ElemTag tag;
    union {
        int data;
        struct { struct GLNode *hp, *tp; } ptr;
    };
}*GList;
int GListDepth(GList &L)
{
    if (!L)
        return 1;
    if (L->tag == ATOM) return 0;
    GList pp;
    for (::max = 0, pp = L; pp != NULL; pp = pp->ptr.tp)
    {
        depth = GListDepth(pp->ptr.hp);
        if (depth > ::max)
            ::max = depth;
    }
    return ::max + 1;
}
// 将非空串str分割成两部分:hsub为第一个','之前的子串,str为之后的子串
void sever(char* ch1, char* ch2)
{
    int n = strlen(ch1);
    int k = 0;//k represent the numbers of left bracket which is not identified
    int i = 0;
    char ch;
    do {
        ++i;
        ch = ch1[i-1];
        if (ch == '(')
            k++;
        else if (ch == ')')
            k--;
    } while (i < n && (ch != ',' || k != 0));
    if(i<n)
    {
        strncpy(ch2, ch1, i-1);
        char s3[100] = { '\0' };
        strncpy(s3, ch1 + i,n-i);
        strcpy(ch1, s3);
    }
    else
    {
        strcpy(ch2, ch1);
        ch1[0]='\0';
    }
}
void CopyGList(GList &T, GList &L)
{
    if (!L)
        T = NULL;
    else
    {
        if (!(T = (GList)malloc(sizeof(GLNode))))
            exit(EOVERFLOW);
        T->tag = L->tag;
        if (L->tag == ATOM) T->data = L->data;
        else {
            CopyGList(T->ptr.hp, L->ptr.hp);
            CopyGList(T->ptr.tp, L->ptr.tp);
        }
    }
}
GList GetHead(GList &L)
{
    if (!L)
        return NULL;
    else
    {
        GList p, q;
        q = NULL;
        p = L->ptr.tp;
        L->ptr.tp = NULL;
        CopyGList(q, L);
        L->ptr.tp = p;
        return q;
    }
}
GList GetTail(GList &L)
{
    GList t=(GList)malloc(sizeof(GLNode));
    if (!L)
        return NULL;
    else
    {
        CopyGList(t, L->ptr.tp);
        return t;
    }
}
void CreatGList(GList &L,char* s1)
{
    if (strcmp(s1, "()")==0)
    {
        L = NULL;
    }
    else
    {
        if (!(L = (GList)malloc(sizeof(GLNode))))
            exit(EOVERFLOW);
        if (strlen(s1) == 1)
        {
            L->tag = ATOM;
            L->data = *s1 - '0';
        }
        else {
            L->tag = LIST;
            GList q;
            GList p = L;
            char s[20] = {'\0'};
            strncpy(s, s1 + 1, strlen(s1) - 2);
            do {
                char hsub[100] = {'\0'};
                sever(s, hsub);
                CreatGList(p->ptr.hp, hsub);
                q = p;
                if (strlen(s)!=0)
                {
                    if (!(p = (GLNode*)malloc(sizeof(GLNode))))
                        exit(OVERFLOW);
                    p->tag = LIST;
                    q->ptr.tp = p;
                }
            } while (strlen(s) != 0);
            q->ptr.tp = NULL;
        }
    }
}
void DestroyGList(GList L)
{
    GList p1, p2;
    if (L)
    {
        if (L->tag == ATOM)
        {
            free(L);
            L = NULL;
        }
        else
        {
            p1 = L->ptr.hp;
            p2 = L->ptr.tp;
            free(L);
            L = NULL;
            DestroyGList(p1);
            DestroyGList(p2);
        }
    }
}

int main()
{
    char gListContext[100] = {'\0'};
    cin >> gListContext;
    GList GList1 = (GList)malloc(sizeof(GLNode));
    CreatGList(GList1, gListContext);
    cout << GListDepth(GList1);
    system("pause");
    return 0;
}
