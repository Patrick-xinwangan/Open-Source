#include<stdio.h>
#include<stdlib.h>
typedef struct Matrix1{
    int row;
    int column;
    int data;
}Matrix;

int main()
{
    int n;//The quantities of the Matrix
    scanf("%d", &n);
    Matrix* MArray = (Matrix*)malloc(n * sizeof(Matrix));
    for (int i = 0; i <= n - 1; i++)
    {
        printf("Please input the information about the matrix:\n");
        printf("Row number,Colum number,Data of the element:\n");
        scanf("%d%d%d", &MArray[i].row, &MArray[i].column, &MArray[i].data);
    }
    for (int i = 0; i <= n - 1; i++)
    {
        int mid=MArray[i].column;// It plays a role as a transfer station
        MArray[i].column = MArray[i].row;
        MArray[i].row = mid;
        //Data has no need to change
    }
    printf("The information of the transfered Matrix are as following:\n");
    for (int i = 0; i <= n - 1; i++)
    {
        printf("The No.%d element:", i + 1);
        printf("Row:%d Column:%d Data:%d\n", MArray[i].row, MArray[i].column, MArray[i].data);
    }
    return 0;
}
