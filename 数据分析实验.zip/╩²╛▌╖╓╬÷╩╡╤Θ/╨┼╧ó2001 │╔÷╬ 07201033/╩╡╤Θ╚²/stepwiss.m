%%�𲽻ع�ı��
function[OutBeta,outbeta]=stepwiss(X,y,alphaE,alphaD)
if nargin<2
    error('�����������Ӧ��������')
end
if nargin<3
    alphaE=0.05;
end
if nargin<4
    alphaD=0.05;
end
if((alphaE<0)||(alphaE>1)||(alphaD<0)||(alphaD>1))
    error('����ˮƽ�����ڣ�0��1��֮��')
end
if alphaE>alphaD
    error('��������ˮƽӦ�ò�С��ɾ������ˮƽ')
end
[m,n]=size(X);[my,ny]=size(y);
if(m~=my)||(ny~=1)
    error('�������y��������x������ȵ�������')
end
A=[ones(m,1),X];
inmd=[1,zeros(1,n)];
Fmd=zeros(1,n+1);
Outall=zeros(1,n+2);
FE=finv(1-alphaE,1,m);
FD=finv(1-alphaD,1,m);
SSA=(y-mean(y))'*(y-mean(y));
for k=1:n
    ind=inmd;
    ind(k+1)=1;
    [SSEk,xshs]=fssa(A,y,ind);
    Fmd(k+1)=(SSA-SSEk)/SSEk*(m-2);
end
[Fk1,k]=max(Fmd);
if Fk1<=FE
    disp('���б�����������')
    return 
else
    inmd(k)=1;
end
[SSEk,xshs]=fssa(A,y,inmd);
Outall(1,:)=xshs;
done=1;
while done
    done=0;
    L=1+length(find(Outall(1,2:end-1)));
    xsh=Outall(1,1:(end-1));
    [SSA,xshs]=fssa(A,y,xsh);
    ind=~Outall(1,1:(end-1));
    ind(1)=0;
    tind=find(ind);
    Fmd=zeros(1,n+1);
    FE=finv(1-alphaE,1,m-L);
    temp=zeros(n+1,n+2);
    ind=Outall(1,1:(end-1));
    for k=tind
        indx=ind;
        indx(k)=1;
        [SSAk,xshs]=fssa(A,y,indx);
        temp(k,:)=xshs;
        Fmd(k)=(SSA-SSAk)/SSAk*(m-L-1);
    end
[Fk1,k]=max(Fmd);
if(Fk1>FE)&&(~ismember(temp(k,:),Outall,'rows'))
    done=1;
    Outall=[temp(k,:);Outall];
end
xsh=Outall(1,1:(end-1));
L=1+length(find(Outall(1,2:end-1)));
[SSA,xshs]=fssa(A,y,xsh);
MSE=SSA/(m-L);
ind=Outall(1,1:(end-1));
ind(1)=0;
tind=find(ind);
Fmd=inf*zeros(1,n+1);
FD=finv(1-alphaD,1,m-L);
temp=zeros(n+1,n+2);
ind=Outall(1,1:(end-1));
for k=tind
    indx=ind;indx(k)=0;
    [SSAk,xshs]=fssa(A,y,indx);
    temp(k,:)=xshs;
    Fmd(k)=(SSAk-SSA)/MSE;
end
[Fk1,k]=min(Fmd);
if Fk1<FD&&(~ismember(temp(k,:),Outall,'rows'))
    done=1;
    Outall=[temp(k,:);Outall];
end
end
Outall=(flipud(Outall));
OutBeta=Outall;
SST=(y-mean(y))'*(y-mean(y));
Outall(:,end)=[];
[M,N]=size(Outall);
outbeta=zeros(size(Outall));
for k=1:M
    tmp=Outall(k,:);
    tmp(1)=0;ind=find(tmp);
    Xtm=A(:,ind);
    mnx=mean(Xtm);
    MNX=repmat (mnx,length(Xtm),1);
    Ljj=diag((Xtm-MNX)'*(Xtm-MNX));
    tmp(ind)=abs(tmp(ind).*sqrt(Ljj'/SST));
    outbeta(k,:)=tmp;
end
function [SSE,xshs]=fssa(A,y,inmod)
inmod(1)=1;
ind=find(inmod);
X=A(:,ind);
b=X\y;
ycap=X*b;
SSE=(y-ycap)'*(y-ycap);
SST=(y-mean(y))'*(y-mean(y));
SSR=(ycap-mean(y))'*(ycap-mean(y));
inmod(ind)=b;
xshs=[inmod,sqrt(SSR/SST)];


% [beta,stats]=regres2(X,y),[BETA,bt]=stepwiss(X,y)

% X=[7 26 6 60;1 29 15 52;11 56 8 20;
%    11 31 8 47;7 52 6 33;11 55 9 22;
%    3 71 17 6;1 31 22 44;2 54 18 22;
%    21 47 4 26;1 40 23 34;11 66 9 12;
%    10 68 8 12];
% y=[78.5;74.3;104.3;87.6;95.9;109.2;102.7;72.5;93.1;115.9;83.8;113.3;109.4];
% [beta,stats]=regres2(X,y);
% beta,table=stats{1},R=stats{2},S=stats{3},Pj=stats{4}

